package test;

public interface Rentable {
	public void rent();
}
