package ex01;

public class MyFunctionClass implements MyFunction {

	@Override
	public int myMethod(String s) {
		return s.length();
	}

}
