package ex01;

@FunctionalInterface
interface MyFunction {
	int myMethod(String s);
}
