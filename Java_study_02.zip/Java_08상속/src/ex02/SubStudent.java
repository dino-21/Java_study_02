package ex02;

public class SubStudent extends Student{

}
