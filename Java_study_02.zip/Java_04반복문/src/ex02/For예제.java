package ex02;

public class For예제 {

	public static void main(String[] args) {
		
		int sum = 0; 
		
		for(int i=101; i<=100; i++) {
			sum += i;
		}
		
		System.out.println(sum);

	}

}
