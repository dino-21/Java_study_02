package ex02;

public class For예제2 {

	public static void main(String[] args) {
		
		for(int i=2; i<=9; i++)
			for(int j=1; j<=9; j++)
				System.out.printf("%dX%d=%d\n",i,j,i*j);

	}

}
