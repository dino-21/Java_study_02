package ex07;

public class MyClassMain {

    public static void main(String[] args) {
        // 인스턴스 생성
        MyClass myInstance = 
         new MyClass("This is an instance variable");

        // 인스턴스 메소드 호출
        myInstance.instanceMethod();
    }

}
