package ex05;

public class 진도개 extends Dog{
	
	void func2() {
		
	}
	void speak() {
		System.out.println("멍멍~ 진도개");
	}
}
