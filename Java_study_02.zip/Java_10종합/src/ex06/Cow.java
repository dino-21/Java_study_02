package ex06;

public class Cow extends Animal{
	
	public Cow() {
		
	}

	@Override
	void speak() {
		System.out.println("멍멍~진도개");
		
	}
}
