package ex04;

public class 진도개 extends Dog{
	
	void func2() {
		
	}
	void speak() {
		
	}
}
