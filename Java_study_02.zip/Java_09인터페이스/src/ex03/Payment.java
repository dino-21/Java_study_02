package ex03;

public interface Payment {
	void makePayment(double amount);
}
