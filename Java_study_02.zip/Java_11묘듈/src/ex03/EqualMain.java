package ex03;

import java.util.HashSet;

class A {
	String id;
	int age;

	A(String id, int age) {
		this.id = id;
		this.age = age;

	}
	
	/*
	 * 기본 자료형이나 String과 같은 클래스는 equals()와 hashCode()가 이미 적절히 구현되어 있어 중복 체크를 잘 해주지만,
	 * 사용자가 정의한 객체는 Object 클래스의 기본 equals()와 hashCode()로는 중복 체크가 제대로 되지 않기 때문에, 
	 * 사용자가 원하는 방식으로 재정의해야 한다. 
	 * 
	 * hashCode()는 객체를 빠르게 식별하기 위한 정수 값
	 * hashCode()는 DB의 인덱스나 기본키처럼, 내부에서 빠른 검색을 위한 기준 값으로 쓰임.
	 * hashCode()는 자바 객체에 붙는 "검색 최적화용 번호"로, DB의 인덱스나 기본키처럼 빠른 탐색을 가능하게 해주는 도구
	 * 	equals()를 재정의하면 hashCode()도 같이 재정의해야 함
	 * 
	 * 사용자 정의 객체는 HashSet이나 HashMap에서 중복 처리를 제대로 하려면 equals()와 hashCode()를 반드시 재정의해야 한다.
	 */
	

	/*
	 * HashSet은 객체의 중복을 허용하지 않기 때문에, 
	 * 객체의 ID나 특정 속성값이 중복 저장되지 않도록 하기 위해서는 
	 * equals()와 * hashCode() 메서드를 재정의해야 한다.
	 * 이 예제는 age가 같으면 중복저장이 되게 하지 않는 예제로 hashCode()와 equals()를 재정의 해야함
	 */

	
	
	
	@Override
	public boolean equals(Object obj) {
		System.out.println("equals........");
		A a = (A) obj;
		return age == a.age;    //오직 age만 비교
	}
	

	
	
	@Override // hashCode()는 원래 객체(Object)에서만 사용 가능한 메서드
	public int hashCode() {
		System.out.println("hashcode........");
		// int는 hashCode()를 못 쓰니까 Integer 클래스의 정적 메서드를 써서 해시값 생성
		return Integer.hashCode(age);
	}

	@Override
	public String toString() {
		return "A [id=" + id + ", age=" + age + "]";
	}

}

public class EqualMain {
	public static void main(String[] args) {
		A a1 = new A("Id12367", 20);
		A a2 = new A("Id12345", 20);  // (id는 다르지만, 나이만 같아서 같은 객체로 취급)
		A a3 = new A("Id12345", 21);
		System.out.println(a1.equals(a2)); // a1과 a2는 "같은 사람"으로 간주

		HashSet<A> set = new HashSet();
		set.add(a1);
		set.add(a2);
		set.add(a3);

		for (A a : set)
			System.out.println(a);
	}
}
