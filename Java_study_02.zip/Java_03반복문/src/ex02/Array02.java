package ex02;

public class Array02 {

	public static void main(String[] args) {
		
		int[] nArr = new int[5];
	   
		nArr[0] = 70;
		nArr[1] = 80;
		nArr[2] = 90;
		nArr[3] = 100;
		for(int i=0; i<5; i++)
			System.out.println(nArr[i]);
		
//		System.out.println(nArr[0]);
//		System.out.println(nArr[1]);
//		System.out.println(nArr[2]);
//		System.out.println(nArr[3]);
//		System.out.println(nArr[4]);
   
	}

}
