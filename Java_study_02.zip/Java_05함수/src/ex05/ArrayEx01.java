package ex05;

public class ArrayEx01 {

	public static void main(String[] args) {
		int a;   //초기화 안되있음.
		
		int[] arr1 = new int[5]; //각 방에는 0으로 초기화
		
		int[] arr2 = {10,20,30,40,50};
		
		int[] arr3 = new int[] {10,20,30,40,50};
//		int[] arr4 = new int[5] {10,20,30,40,50};  첨자는 생략
		
		String[] str =new String[5];  //각 방에는 null 초기화
		
		System.out.println(arr2);

	}

}
