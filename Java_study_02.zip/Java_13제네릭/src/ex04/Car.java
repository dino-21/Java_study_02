package ex04;

public class Car {
	Car(){
    	System.out.println("Car");
    	
    }

	@Override
	public String toString() {
		return "Car";
	}
	
}
