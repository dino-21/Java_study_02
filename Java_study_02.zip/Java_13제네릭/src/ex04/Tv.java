package ex04;

public class Tv {
    Tv(){
    	System.out.println("TV");
    	
    }

	@Override
	public String toString() {
		return "Tv";
	}
    
}
