package ex05;



class A {
}

class B extends A {
}

class C extends B {
}

class Box<T extends A> { // T 전달될 수있는 대상은 A거나 A 하위(자손) 클래스만 가능
	private T obj;

	public T getObj() {
		return obj;
	}

	public void setObj(T obj) { // public void setObj(A obj)
		this.obj = obj;
	}
}

public class 타입제한하기 {
	/*
	Box<T extends A> → T는 A 또는 A의 하위 클래스만 가능
	Box<A> → A, B, C 객체 모두 set 가능. 하지만 get은 A 타입으로만 반환됨
	Box<B> → B, C 객체만 set 가능. get은 B 타입으로 반환됨
	Box<C> → C 객체만 set 가능. get은 C 타입으로 반환됨
	
	 1 setObj(T obj) — 값을 넣을 때
     Box<A>는 A, B, C 객체 모두 업캐스팅해서 저장할 수 있다.
     상위 타입으로 받는다는 문제 없음
     Box<A> aBox = new Box<>();
     aBox.setObj(new A()); // OK
     aBox.setObj(new B()); // OK (업캐스팅)
     aBox.setObj(new C()); // OK (업캐스팅)



     2  getObj() — 값을 꺼낼 때
     Box<A>의 getObj()는 항상 A 타입으로 반환
     실제로는 B나 C 객체가 들어있었다면, 그것을 B나 C로 사용하려면 명시적 형변환(다운캐스팅) 해야 한다.
     
     setObj()	항상 가능 (업캐스팅)	상위 타입으로 포장 가능
     getObj()	위험 가능성 있음 (다운캐스팅 시)	실제 타입과 일치해야 안전
     
     3 실무에서는 가능하면 다운캐스팅을 피하거나,
       instanceof 체크 후 형변환하거나,
       제네릭 타입을 명확히 관리해서 오류를 사전에 차단
	*/
	
	
	public static void main(String[] args) {
		// Box<A>는 A 타입으로 선언되었기 때문에,
		// setObj에는 A 또는 A의 하위 객체(B, C 등)를 넣을 수 있고,
		// getObj는 항상 A 타입으로 반환된다. (하위 타입 사용 시 다운캐스팅 필요)
		Box<A> aBox = new Box();

		// Box<B>는 B 타입으로 선언되었기 때문에,
		// setObj에는 B 또는 그 하위 타입(C 등)을 넣을 수 있고,
		// getObj는 항상 B 타입으로 반환된다.
		Box<B> bBox = new Box();

		// Box<C>는 C 타입으로 선언되었기 때문에,
		// setObj에는 C 타입 객체만 넣을 수 있고,
		// getObj는 항상 C 타입으로 반환된다.
		Box<C> cBox = new Box();

		aBox.setObj(new A());
		A a = aBox.getObj();

		aBox.setObj(new B());
		B b = (B) aBox.getObj();

		aBox.setObj(new C());
		C c = (C) aBox.getObj();

//		Box<String> sBox = new Box();
//		Box<Integer> iBox = new Box();
	}

}



